#ifndef __CONFIG_H__
#define __CONFIG_H__

/*
0, 4, 0, 14
QHYCCD  (Beijing) Technology Co., Ltd.

system_profiler SPUSBDataType

/lib/firmware/qhy
*/


//Module compilation switch part
#undef 	GIGAESUPPORT
#undef 	AuxImage
#undef 	WIN_98_DDK

#if defined (_WIN32)
#define QHYCCD_OPENCV_SUPPORT
#else
#undef  QHYCCD_OPENCV_SUPPORT
#endif



#endif

