

int resetcamera();
